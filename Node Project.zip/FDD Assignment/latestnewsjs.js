document.addEventListener("DOMContentLoaded", function () {
  const imageLinks = document.querySelectorAll(".news-slider a");
  const sliderInterval = 10000; // Change image every 10 seconds (10,000 milliseconds)
  let currentSlide = 0;
  let sliderTimer;

  function showSlide(slideIndex) {
    imageLinks.forEach((link, index) => {
      if (index === slideIndex) {
        link.style.display = "block";
      } else {
        link.style.display = "none";
      }
    });
  }

  function startSlider() {
    sliderTimer = setInterval(() => {
      currentSlide = (currentSlide + 1) % imageLinks.length;
      showSlide(currentSlide);
    }, sliderInterval);
  }

  function stopSlider() {
    clearInterval(sliderTimer);
  }

  showSlide(currentSlide);
  startSlider();

  // Manual navigation controls
  const prevButton = document.getElementById("prevButton");
  const nextButton = document.getElementById("nextButton");

  prevButton.addEventListener("click", () => {
    currentSlide = (currentSlide - 1 + imageLinks.length) % imageLinks.length;
    showSlide(currentSlide);
    stopSlider();
    startSlider();
  });

  nextButton.addEventListener("click", () => {
    currentSlide = (currentSlide + 1) % imageLinks.length;
    showSlide(currentSlide);
    stopSlider();
    startSlider();
  });
});