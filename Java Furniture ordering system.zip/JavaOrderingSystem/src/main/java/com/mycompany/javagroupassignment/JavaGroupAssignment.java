/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javagroupassignment;

/**
 *
 * @author youss
 */
public class JavaGroupAssignment {

    public static void main(String[] args) {
       LoginPage LoginFrame = new LoginPage();
       LoginFrame.setVisible( true);
       LoginFrame.pack();
       LoginFrame.setLocationRelativeTo(null);
       
    }
}
